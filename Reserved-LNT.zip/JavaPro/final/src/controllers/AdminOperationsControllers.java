package controllers;
public interface AdminOperationsControllers {

	void addRestaurant();
	void getRestaurant(int restaurantId);
	void updateRestaurant(int restaurantId);
	void deleteRestaurant(int restaurantId);
}
