package controllers;
import java.util.*;
import java.sql.Date;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;

import com.sun.xml.internal.messaging.saaj.packaging.mime.internet.ParseException;

import application.Main;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

public class ReservationController {
	private int id;
	private int restaurantID;
	private int reservationID;
	private int customerid;
	private int tableid;
	private LocalDateTime dateTime;
	private int numOfGuests;
	@FXML
	private TextField txtnumOfGuest;

	@FXML
	private TextField txtdTime;
	
	@FXML
	private Label lblErr;
	private Scanner sc;
	
	public ReservationController() {
		
	}
	
	public ReservationController(int id, int resturantid, int customerid, int tableid, LocalDateTime dateTime, int numOfGuests) {
		super();
		this.id = id;
		this.reservationID = reservationID;
		this.customerid = customerid;
		this.tableid = tableid;
		this.dateTime = dateTime;
		this.numOfGuests = numOfGuests;
	}
	public void reserve()  {
		int guestCt = Integer.parseInt(txtnumOfGuest.getText());
		ReservationController reserve = new ReservationController();
		Scanner sc = new Scanner(System.in);
		String dobDate = sc.next("Date");       
		SimpleDateFormat parseDate = new SimpleDateFormat("MM/dd/yyyy");
		Date dobFDate;
		try {
		dobFDate = (Date)parseDate.parse(dobDate);
		}
		catch(Exception e) {
			System.out.println("Error occured while inflating view: " + e);
		}
	}

	public void confirm() {
		System.out.println("Booking Confirmed for "+numOfGuests+"on date "+dateTime);
		
		try {
		    AnchorPane root = (AnchorPane)FXMLLoader.load(getClass().getResource("/views/LoginView.fxml"));
			Scene scene = new Scene(root);
			Main.stage.setScene(scene);
			Main.stage.setTitle("Login");
		} catch(Exception e) {
			System.out.println("Error occured while inflating view: " + e);
		}
	}
	
	public void logout() {
		System.exit(0);
		try {
		    AnchorPane root = (AnchorPane)FXMLLoader.load(getClass().getResource("/views/LoginView.fxml"));
			Scene scene = new Scene(root);
			Main.stage.setScene(scene);
			Main.stage.setTitle("Login");
		} catch(Exception e) {
			System.out.println("Error occured while inflating view: " + e);
		}
	}
}
