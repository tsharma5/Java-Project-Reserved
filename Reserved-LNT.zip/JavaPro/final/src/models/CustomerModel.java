package models;


public class CustomerModel extends UserModel {


	public CustomerModel() {
		
	}
}
